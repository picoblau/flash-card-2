criaCartao(
    'Geografia',
    'Quais os relevos do brasil?',
    'planaltos, planícies e depressões'
)

criaCartao(
    'Fisica',
    'quantos planetas tem no sistema solar?',
    'oito'
)

criaCartao(
    'Programação',
    'pra que serve o HTML?',
    'Define o significado e a estrutura do conteúdo da web'
)

criaCartao(
    'Lingua inglesa',
    'Como se diz dia de pagamento em inglês ?',
    'pay day'
)